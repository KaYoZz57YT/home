#!/bin/bash
./runtime/getchangedsrc.py "$@"
