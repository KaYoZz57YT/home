#!/bin/bash
./runtime/cleanup.py "$@"
